using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class FieldOfViewVisual : MonoBehaviour
{
    [Header("Parent")]
    [SerializeField] private Transform parent;

    [Header("Field Of View")]
    [SerializeField] private List<TypeFOV> typeFOVList;

    private Dictionary<SoldierSO.SoldierDirection, TypeFOV> fovDict;

    private IHasFieldOfView hasFieldOfView;

    private void Awake() {

        // Init dict
        fovDict = new Dictionary<SoldierSO.SoldierDirection, TypeFOV>();

        foreach(TypeFOV currentFOV in typeFOVList) {

            if (!fovDict.ContainsKey(currentFOV.soldierDirection)) {

                fovDict.Add(currentFOV.soldierDirection, currentFOV);
            }
        }

        // Parent event subcribe
        hasFieldOfView = parent.GetComponent<IHasFieldOfView>();

        if (hasFieldOfView == null) {
            Debug.LogError("Parent dont inherit hasFieldOfView interface");
        }

        hasFieldOfView.UnlockFOV += HasFieldOfView_UnlockFOV;
        hasFieldOfView.OnFOV += HasFieldOfView_OnFOV;
        hasFieldOfView.OffFOV += HasFieldOfView_OffFOV;
    }

    private void Start() {
        
        // After Spawn
        foreach (TypeFOV typeFOV in typeFOVList) {

            HideFOV(typeFOV.fov);
        }
    }

    private void OnDestroy() {

        hasFieldOfView.UnlockFOV -= HasFieldOfView_UnlockFOV;
        hasFieldOfView.OnFOV -= HasFieldOfView_OnFOV;
        hasFieldOfView.OffFOV -= HasFieldOfView_OffFOV;
    }

    private void HasFieldOfView_OffFOV(object sender, System.EventArgs e) {

        Sequence offFOVSequence = DOTween.Sequence();
        float duration = 0.2f;

        foreach (TypeFOV typeFOV in typeFOVList) {

            if (typeFOV.IsUnlocked() & typeFOV.fov.gameObject.activeSelf) {
                // If current fov is unlocked and are active

                SpriteRenderer spriteRenderer = typeFOV.fov.GetComponent<SpriteRenderer>();

                offFOVSequence.Join(spriteRenderer.DOFade(0f, duration).SetEase(Ease.Linear)).OnComplete(() => {

                    HideFOV(typeFOV.fov);
                });
            }
        }
    }

    private void HasFieldOfView_OnFOV(object sender, System.EventArgs e) {

        Sequence offFOVSequence = DOTween.Sequence();
        float duration = 0.2f;

        foreach (TypeFOV typeFOV in typeFOVList) {

            if (typeFOV.IsUnlocked() & !typeFOV.fov.gameObject.activeSelf) {
                // If current fov is unlocked and are not active

                SpriteRenderer spriteRenderer = typeFOV.fov.GetComponent<SpriteRenderer>();

                Color tempColor = spriteRenderer.color;
                tempColor.a = 0f;
                spriteRenderer.color = tempColor;

                ShowFOV(typeFOV.fov);
                

                offFOVSequence.Join(spriteRenderer.DOFade(1f, duration).SetEase(Ease.Linear));
            }
        }
    }

    private void HasFieldOfView_UnlockFOV(object sender, IHasFieldOfView.UnLockFOVEventArgs e) {
        
        if (fovDict[e.soldierDirection].IsUnlocked()) {
            // If this fov is unlocked
            return;
        }

        UnlockFOV(e.soldierDirection);
    }

    private void UnlockFOV(SoldierSO.SoldierDirection soldierDirection) {

        // 1.
        Transform fov = fovDict[soldierDirection].fov;
        fov.localScale = Vector3.zero;
        fovDict[soldierDirection].SetIsUnlocked(true);
        ShowFOV(fov);

        // 2.
        Sequence unlockSequence = DOTween.Sequence();
        float duration = 0.2f;

        //
        unlockSequence.Append(fov.DOScale(Vector3.one, duration).SetEase(Ease.Linear));
        
    }

    private void ShowFOV(Transform fov) {
        fov.gameObject.SetActive(true);
    }

    private void HideFOV(Transform fov) {
        fov.gameObject.SetActive(false);
    }

}

[System.Serializable]
public class TypeFOV {

    public SoldierSO.SoldierDirection soldierDirection;
    public Transform fov;

    private bool isUnlockedFOV;

    private TypeFOV() {

        SetIsUnlocked(false);   
    }

    public bool IsUnlocked() {
        return this.isUnlockedFOV;
    }

    public void SetIsUnlocked(bool isUnlocked) {
        this.isUnlockedFOV = isUnlocked;
    }
}

