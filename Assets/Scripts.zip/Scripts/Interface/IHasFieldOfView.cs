using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IHasFieldOfView
{
    public event EventHandler<UnLockFOVEventArgs> UnlockFOV;
    public class UnLockFOVEventArgs : EventArgs {
        public SoldierSO.SoldierDirection soldierDirection;
    }

    public event EventHandler OnFOV;
    public event EventHandler OffFOV;
}
